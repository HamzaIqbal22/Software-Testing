package test;

import static org.junit.Assert.assertEquals;
import main.RE;

import org.junit.Before;
import org.junit.Test;

public class RETest {
		
	@Test
	public void validTest() {
		
		//check for valid matching
		String num = "123-456-6789";
		
		//Should result in true since format should match
		boolean check = true;
		assertEquals ( check ,RE.checkPhoneNumber(num));
				
	}
	
	@Test
	public void invalidTest() {
		
		//check for invalid input
		String num = "12312312312";
				
		//result from checkPhoneNumber method should result in false since its a wrongly formatted input		
		boolean check = false;
		assertEquals ( check ,RE.checkPhoneNumber(num));
	}
	
	
	@Test
	public void valid2Test() {
		//check for valid matching
		String num = "(123) 456 6789";
				
		//Should result in true since format should match
		boolean check = true;
		assertEquals ( check ,RE.checkPhoneNumber(num));
		
	}
	
	
	
	
}
