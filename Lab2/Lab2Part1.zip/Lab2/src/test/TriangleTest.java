package test;

import static org.junit.Assert.*;
import main.Triangle;

import org.junit.Before;
import org.junit.Test;

public class TriangleTest {

	Triangle t1;
	Triangle t2;
	Triangle t3;
	
	@Before
	public void init (){
		t1 = new Triangle(3,4,5);
		t2 = new Triangle(5,4,3);
		t3 = new Triangle(8,5,5);
		
	}
		
	@Test
	public void t1Test() {
		System.out.println("\n\t t1: ");
		assertEquals ( 6 ,(int)t1.calculateArea());		
	}
	
	@Test
	public void t2Test() {
		System.out.println("\n\t t2: ");
		assertEquals ( 6 ,(int)t2.calculateArea());
		
	}
	
	@Test
	public void t3test() {
		System.out.println("\n\t t3: ");
		assertEquals ( 12 ,(int)t3.calculateArea());
		
	}
	
	@Test
	public void equalsTest() {
		System.out.println("\n\t t1 & t2: ");
		assertEquals ((int)t1.calculateArea() ,(int)t2.calculateArea());    
	}

	
	@Test(expected = IllegalArgumentException.class)
	public void negativeTest() {
		Triangle t4 = new Triangle (-5,-5,-5);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void largeTest() {
		Triangle t5 = new Triangle (4,3,100);
	}
}
