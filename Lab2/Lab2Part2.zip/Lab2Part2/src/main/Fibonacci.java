package main;

public class Fibonacci {
	public static int compute(int n) {
	    int result = 0;
	    
	    if (n <= 1) {
	    	result = n;
	            
	    } else {
	        result = compute(n - 1) + compute(n - 2); 
	    }
	         
	    return result;    
	}
	
	public static void main (String [] args){
	/*	
		System.out.println(Fibonacci.compute(0));
		System.out.println(Fibonacci.compute(1));
		System.out.println(Fibonacci.compute(2));
		System.out.println(Fibonacci.compute(3));
		System.out.println(Fibonacci.compute(4));
		System.out.println(Fibonacci.compute(5));
		System.out.println(Fibonacci.compute(6));
		System.out.println(Fibonacci.compute(7));
		System.out.println(Fibonacci.compute(8));
		System.out.println(Fibonacci.compute(9));	
	*/
	}
		
}
	
	

