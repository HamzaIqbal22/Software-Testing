package main;

public class PrimeNumberChecker {
    
    public static boolean checkPrime(int n) {
        
        //Prime number cannot be 1 or anything less than
        if (n <= 1) {
            return false;
        }
        
        //check for divisors other than 1 or itself of input number  
        for (int i = 2; i<n; i++) {
            
            if (n % i == 0)
                return false;
        }
        return true;
    }

}