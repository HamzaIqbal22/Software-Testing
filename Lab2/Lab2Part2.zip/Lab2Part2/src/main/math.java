package main;

public  class math {
	
	
	
	public static boolean theory (int a, int b){
		boolean check = false;
		
		if (a>0 && b>0 && a+b > a && a+b >b){
			check = true;
		}
		
		return check;
	}
	
	public static boolean commutative (int a, int b){
		boolean check = false;
		
		if (a+b == b+a){
			check = true;
		}
		return check;
	}
	
	
	
	public static void main (String [] args){
		
		
		math m = new math ();
		/*
		System.out.print(m.theory(0, 2));
		System.out.print(m.theory(0, 2));
		System.out.print(m.theory(0, 2));
		System.out.print(m.theory(0, 2));
		System.out.print(m.theory(0, 2));
		System.out.print(m.theory(0, 2));
		System.out.print(m.theory(0, 2));	
		*/
	}
	
}
