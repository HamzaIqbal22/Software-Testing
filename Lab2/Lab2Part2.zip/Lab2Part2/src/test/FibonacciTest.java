package test;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import main.Fibonacci;


import java.util.Arrays;
import java.util.Collection;
import static org.junit.Assert.*;

@RunWith(Parameterized.class)
public class FibonacciTest {
       
		//Instance variables corresponding to input 'n' & output 'result' in Fibonacci class
	  	private int expected;
        private int index;

        public FibonacciTest(int index, int expected) {
        	this.expected = expected;
        	this.index = index;
        }
        
        @Parameterized.Parameters
        public static Iterable<Object[]> data(){
            return Arrays.asList(new Object[][] {     
               { 0, 0 },
               { 1, 1 }, 
               { 2, 1 }, 
               { 3, 2 }, 
               { 4, 3 }, 
               { 5, 5 }, 
               { 6, 8 }, 
               { 7, 13},
               { 8, 21},
               { 9, 34}}
            );    
        }  

        @Test
        public void testIsValid() throws Exception {
            int actual = Fibonacci.compute(index);
            assertEquals(expected, actual);
            
        }
}